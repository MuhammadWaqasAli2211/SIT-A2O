# Handoff: "Choose Your Track" Section

## Overview
A program-selection section for the Bootcamp Flows site (a free tech bootcamp platform). It sits below the existing hero section and lets a prospective student browse five training tracks (Web & App Development, Mobile Development, Data Science & AI, Cloud & DevOps, UI/UX Design) via an interactive fanned card stack, and see full details of whichever track is selected in a panel alongside it.

## About the Design Files
The file in this bundle (`choose-your-track.dc.html`) is a **design reference built in HTML** — a working prototype showing intended look, layout, and interaction, not production code to copy directly. The task is to **recreate this design in the target codebase's existing environment** (React, Vue, etc.) using its established components and patterns — or, if no frontend framework exists yet, to choose the most appropriate one and implement it there.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and interaction behavior are final — recreate pixel-for-pixel using the codebase's existing libraries where equivalent utilities exist (e.g. Tailwind, styled-components).

## Screens / Views

### Section: Choose Your Track
**Purpose:** Let the user browse the 5 available bootcamp tracks and inspect one in detail.

**Layout:**
- Full-width section, white background, `100px 80px` padding.
- Header block: centered, `max-width: 640px`, margin `0 auto 72px`.
  - Eyebrow pill: "5 TRACKS · ALL FREE" — light green background `#eafaf0`, text `#0f7a37`, `13px` font-weight 600, pill radius `999px`, padding `6px 14px`.
  - H2, 44px/1.12 line-height, weight 800, letter-spacing -0.01em: "Choose the track that fits where **you want to go.**" (last 3 words in accent green `#16a34a`).
  - Paragraph, 17px/1.6, color `#475569`.
- Body: two-column grid, `max-width: 1240px` centered, `grid-template-columns: 1fr 1fr`, `gap: 80px`, vertically centered.

**Left column — fanned card stack**
- Container: `position: relative`, height `720px`.
- 5 cards, each `position: absolute`, width `82%`, height `190px`, border-radius `22px`, white background, `1px solid rgba(15,23,42,0.08)` border, `box-sizing: border-box`.
- Stacking geometry (index `i` = 0..4, in track order above):
  - `top = i * 132px`
  - `left = i * 18px`
  - `z-index = i + 1` (inactive), `50` when that card is the active/selected one
  - `rotate = ±2.5deg` alternating by parity (even index -2.5deg, odd +2.5deg); active card resets to `-1deg` and adds `scale(1.03)`
  - Box shadow: inactive `0 8px 20px -8px rgba(15,23,42,0.10)`; active `0 24px 48px -16px rgba(15,23,42,0.22)`
  - Transition: `all 0.3s ease`
- Card content (padding `26px 30px 26px 150px` to leave room for the big number):
  - Big track number ("01"–"05"): `position: absolute; top:-14px; left:-6px`, font-size `80px`, weight 900, color = that track's accent color (see Design Tokens), opacity `0.85` inactive / `1` active.
  - Kicker pill (difficulty label, e.g. "Beginner friendly"): white/translucent background `rgba(255,255,255,0.7)`, `1px solid rgba(15,23,42,0.08)` border, text color = track accent, `11px` uppercase, weight 700, letter-spacing 0.04em, pill radius `999px`, padding `6px 13px`.
  - Title (h3): `21px`, weight 700, color `#0f172a`.
  - Tagline (p): `14px/1.5`, color `#334155`, `max-width: 320px`.
  - Title/tagline opacity: `0.85` inactive, `1` active.
  - Inactive cards get a subtle white wash overlay (`position:absolute; inset:0; background: rgba(255,255,255,0.18)`) to visually recede.
- Interaction: clicking any card sets it as "active" — see State Management.
- **Overlap rule (important for a bug-free rebuild):** the offset between consecutive cards (132px) must stay ≥ the height of each card's own header zone (padding-top + kicker pill + gap + title ≈ 94px) plus a safety buffer, so a card's own title is never covered by the next card in the stack — only its tagline recedes behind the next card. Keep rotation small (±2.5deg) since larger rotation grows a card's visual bounding box and can reintroduce overlap.

**Right column — detail panel**
- `border-radius: 28px`, padding `56px 48px`, `min-height: 460px`, background: `linear-gradient(135deg, color-mix(in srgb, <active track color> 10%, #ffffff) 0%, #ffffff 65%)` — i.e. a soft tint of the active track's color fading to white.
- Big faded number (matches active track's number), `110px`, weight 900, color = `color-mix(in srgb, <track color> 16%, #ffffff)`.
- Kicker pill: white background, `1px solid rgba(15,23,42,0.08)` border, text = track accent color, same pill style as the card kicker, `12px`.
- Title (h3): `34px`, weight 800, color `#0f172a`.
- Description paragraph: `16px/1.65`, color `#334155`, `max-width: 440px`.
- Tag chips row: white background, `13px`, color `#334155`, pill radius `999px`, padding `6px 14px`, `gap: 8px`, wraps.
- Meta row: duration and seat count, `14px`, label color `#475569` with value in `#0f172a` bold; separated by a `1px solid rgba(15,23,42,0.08)` top border, `20px` padding-top.
- CTA button "View curriculum": solid `#16a34a` background, white text, `15px` weight 600, pill radius `999px`, padding `14px 26px`, trailing right-arrow icon (24×24 stroke icon, stroke-width 2).

## Interactions & Behavior
- **Click a stack card → that track becomes active.** The active card animates (0.3s ease) to the front (`z-index: 50`), straightens (`rotate(-1deg)`), scales up slightly (`1.03`), and its white wash disappears. The right-hand detail panel re-renders with that track's number, color tint, title, description, tags, duration, and seats.
- Default active track on load: index 1 (Mobile Development) — can be changed to index 0 if the client prefers the first track selected by default.
- No page navigation occurs on card click; "View curriculum" is a placeholder link (`href="#"`) — wire it to the real curriculum/detail page per track.

## State Management
- Single piece of state: `activeIndex` (number, 0–4), defaulting to `1`.
- Setting `activeIndex` re-derives: which card is visually "front," and which track's data populates the detail panel.
- No async data fetching — track data is static content (see below); wire to a CMS/API if the client wants tracks to be editable without a redeploy.

## Design Tokens

**Colors**
| Token | Hex | Use |
|---|---|---|
| Base text | `#0f172a` | Titles, headings |
| Body text | `#475569` / `#334155` | Paragraphs, meta labels |
| Accent green (brand) | `#16a34a` | Section accent, CTA button, "5 tracks" pill text base |
| Accent green tint | `#eafaf0` | Pill backgrounds |
| Accent green dark | `#0f7a37` | Pill text |
| Border/hairline | `rgba(15,23,42,0.08)` | Card borders, dividers |

**Per-track accent colors** (all green-family, matching the site's existing green theme):
| Track | Color |
|---|---|
| Web & App Development | `#16a34a` |
| Mobile Development | `#0d9488` |
| Data Science & AI | `#15803d` |
| Cloud & DevOps | `#4d7c0f` |
| UI/UX Design | `#0f766e` |

**Typography**
- Font family: Inter (400/500/600/700/800/900 weights loaded)
- H2 (section heading): 44px / 1.12 / weight 800
- H3 (card & panel title): 21px (card) / 34px (panel), weight 700/800
- Body: 14–17px, weight 400

**Spacing / Radius**
- Section padding: 100px 80px
- Card radius: 22px; panel radius: 28px; pills: 999px (full)
- Card-to-card offset: 132px vertical, 18px horizontal

## Track Content (verbatim copy)
1. **Web & App Development** — *Beginner friendly*. Tagline: "Build production-grade web apps with the MERN stack." Description: "A full-stack track covering modern JavaScript, React, Node.js, and databases. You finish with deployed projects, a portfolio, and the workflow habits teams actually expect." Tags: HTML & CSS, JavaScript, React, Node.js, MongoDB, Git. Duration: 6 months. Seats: 300.
2. **Mobile Development** — *Some coding helpful*. Tagline: "Ship cross-platform apps for Android and iOS." Description: "Learn to build, test, and publish mobile apps for iOS and Android using React Native and Flutter, from first screen to app-store release." Tags: React Native, Flutter, Dart, REST APIs. Duration: 5 months. Seats: 150.
3. **Data Science & AI** — *Some coding helpful*. Tagline: "Turn raw data into decisions with Python and ML." Description: "Turn raw data into decisions with Python and machine learning, from cleaning datasets to shipping models that hold up outside the notebook." Tags: Python, Pandas, NumPy, scikit-learn. Duration: 6 months. Seats: 200.
4. **Cloud & DevOps** — *Some coding helpful*. Tagline: "Automate delivery and run infrastructure that scales." Description: "Automate delivery and run infrastructure that scales, covering containers, orchestration, and the pipelines that ship code safely." Tags: Linux, Docker, Kubernetes, CI/CD. Duration: 5 months. Seats: 150.
5. **UI/UX Design** — *Beginner friendly*. Tagline: "Design products people can actually use." Description: "Design products people can actually use, from user research through wireframes to prototypes ready to hand off to engineering." Tags: Figma, User research, Wireframing, Prototyping. Duration: 4 months. Seats: 150.

## Assets
No external image assets — only inline SVG icons (a right-arrow chevron icon used in the CTA button, 24×24, stroke-based). No icon library dependency required; recreate as inline SVG or swap for an equivalent icon from the codebase's existing icon set (e.g. Lucide `arrow-right`).

## Files
- `choose-your-track.dc.html` — the full design reference (self-contained; open directly in a browser). Contains all markup, inline styles, and the interaction logic (click-to-activate) described above.
